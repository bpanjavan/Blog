﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Page4 : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        labelMain.Text = "Go Longhorns!";
        textboxMain.Text = "Go Longhorns!";
        dropdownlistStates.SelectedValue = "Texas";
        label1.Text = "Go Longhorns!";
        textbox1.Text = "Go Longhorns!";
        label2.Text = "Go Longhorns!";
        textbox2.Text = "Go Longhorns!";
        label3.Text = "Go Longhorns!";
        textbox3.Text = "Go Longhorns!";
        label4.Text = "Go Longhorns!";
        textbox4.Text = "Go Longhorns!";
        label5.Text = "Go Longhorns!";
        textbox5.Text = "Go Longhorns!";
        label6.Text = "Go Longhorns!";
        textbox6.Text = "Go Longhorns!";
        label7.Text = "Go Longhorns!";
        textbox7.Text = "Go Longhorns!";
        label8.Text = "Go Longhorns!";
        textbox8.Text = "Go Longhorns!";
        label9.Text = "Go Longhorns!";
        textbox9.Text = "Go Longhorns!";
        label10.Text = "Go Longhorns!";
        textbox10.Text = "Go Longhorns!";
        label11.Text = "Go Longhorns!";
        textbox11.Text = "Go Longhorns!";
        label12.Text = "Go Longhorns!";
        textbox12.Text = "Go Longhorns!";
        label13.Text = "Go Longhorns!";
        textbox13.Text = "Go Longhorns!";
        label14.Text = "Go Longhorns!";
        textbox14.Text = "Go Longhorns!";
        label15.Text = "Go Longhorns!";

    }
}
