﻿using System;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using System.Windows.Media.Imaging;

namespace Silverlight_Binding
{
    public enum CustomerType
    {
        Electricity,
        Gas
    }

    public class Customer
    {
        public String FullName { get; set; }
        public CustomerType Type { get; set; }
        public BitmapImage PhotoID { get; set; }
    }
}






