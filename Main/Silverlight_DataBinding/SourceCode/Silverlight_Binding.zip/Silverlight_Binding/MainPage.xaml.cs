﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using System.Windows.Media.Imaging;

namespace Silverlight_Binding
{
    public partial class MainPage : UserControl
    {
        public MainPage()
        {
            InitializeComponent();
        }

        private void UserControl_Loaded(object sender, RoutedEventArgs e)
        {
            // Binding textboxMain and textblockWhatColor to a solid color brush


            // Create an instance of the MyColors class 
            MyColors myColorMain = new MyColors();
            // MainBrush is set to be a SolidColorBrush with the value Red.
            myColorMain.MainBrush = new SolidColorBrush(Colors.Red);
            myColorMain.MyColorString = "#0000ff";

            // Set the DataContext of the TextBox MyTextBox.
            textboxMain.DataContext = myColorMain;
            
            textblockWhatColor.DataContext = myColorMain.MainBrush;
           
            // binding textblockPersonInformation to a person
            Person bryan = new Person() { Age = 26, FullName = "Bryan Panjavan" };
            textblockPersonInformation.DataContext = bryan;

            // set datacontext of our stackpanel
            Customer bryanCustomer = new Customer(){FullName="Bryan Panjavan",
                                                    Type=CustomerType.Electricity
                                                    };
            bryanCustomer.PhotoID = new BitmapImage(new Uri("link_icon.jpg", UriKind.Relative));
            stackpanelCustomerInformation.DataContext = bryanCustomer;
        }

        private void buttonChangeColor_Click(object sender, RoutedEventArgs e)
        {
            if (((SolidColorBrush)textboxMain.Foreground).Color == System.Windows.Media.Colors.Red)
                ((SolidColorBrush)textboxMain.Foreground).Color = System.Windows.Media.Colors.Green;
            else
                ((SolidColorBrush)textboxMain.Foreground).Color = System.Windows.Media.Colors.Red;
        }
    }
}
