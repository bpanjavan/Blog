﻿using System;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using IntrepidLib.Cover;
using Intrepid.App.Views;
using System.Collections.Generic;
using IntrepidLib.Core;

namespace Intrepid.App.Controllers
{
    public class GameBoardController : IGameBoardController
    {
        private IGameBoard _gameBoardModel;
        private IGameBoardView _gameBoardView;

        public GameBoardController(CoreModel model, Application app)
        {
            int numSpacesX = 10;
            int numSpacesY = 10;
            Dictionary<string, object> gameboardSettings = new Dictionary<string, object>();
            gameboardSettings.Add(GameBoardFactory.GameBoardSettings.NumSpacesX, numSpacesX);
            gameboardSettings.Add(GameBoardFactory.GameBoardSettings.NumSpacesY, numSpacesY);

            IGameBoard gameBoardModel = (model.CoreGameBoardFactory).CreateGameBoard(gameboardSettings);
            this._gameBoardModel = gameBoardModel;
            this._gameBoardView = new GameBoardView(this, _gameBoardModel);
            // now do things to initialize and load the view
            app.RootVisual = (UIElement)_gameBoardView;
            this._gameBoardModel.Load();

            // Add a piece

            _gameBoardModel.AddPiece(1, 2, model.CoreGameBoardFactory.CreatePiece("Hello World"));
            _gameBoardModel.AddPiece(4, 2, model.CoreGameBoardFactory.CreatePiece("Goodbye Cruel World"));
            _gameBoardModel.AddPiece(6, 3, model.CoreGameBoardFactory.CreatePiece("Mai mai"));
            //_gameBoardModel.MovePiece(1, 2, 4, 2);
        }

        //public void _gameBoardView_PieceClicked(object sender, PieceClickedEventArgs e)
        //{
        //    // Decide that we're going to select the piece and do so on the model
        //    IPiece piece = _gameBoardModel.GetSpace(e.LocationX, e.LocationY).Piece;
        //    _gameBoardModel.SelectPiece(piece);
        //}

        public void SpaceClicked(int locationX, int locationY)
        {
            // if a piece is in the middle of moving, do nothing
            if (_gameBoardView.PieceMoving == true)
                return;

            ISpace space = _gameBoardModel.SelectedSpace;
            if (_gameBoardModel.CanMoveToSpace(locationX, locationY))
            {
                _gameBoardModel.MovePiece(space.Piece, locationX, locationY);
                _gameBoardModel.ClearSelectedSpace();
            }
            else
            {
                //select the space
                _gameBoardModel.SelectSpace(_gameBoardModel.GetSpace(locationX, locationY));
            }
        }


    }
}
