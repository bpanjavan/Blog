﻿using System;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using System.Collections.Generic;

namespace IntrepidLib.Cover
{
    internal class GameBoardBase : IGameBoard
    {
        private ISpace[,] _spaces = null;

        internal GameBoardBase(int numSpacesX, int numSpacesY)
        {
            NumSpacesX = numSpacesX;
            NumSpacesY = numSpacesY;
            this.Loaded += new EventHandler(GameBoardBase_Loaded);
            this.PieceAdded += new PieceAddedEventHandler(GameBoardBase_PieceAdded);
            this.PieceMoved += new PieceMovedEventHandler(GameBoardBase_PieceMoved);
            this.SpaceSelected += new SpaceSelectedEventHandler(GameBoardBase_SpaceSelected);
            this.SelectedSpaceCleared += new SelectedSpaceClearedEventHandler(GameBoardBase_SelectedSpaceCleared);
        }

        /// <summary>
        /// Load the gameboard.  Setup the spaces in my grid and fire loaded event
        /// Using the numSpacesX and numSpaces Y
        /// </summary>
        public void Load()
        {
            _spaces = new ISpace[NumSpacesX, NumSpacesY];
            for (int i = 0; i < NumSpacesX; i++)
            {
                for (int j = 0; j < NumSpacesY; j++)
                {
                    SpaceBase newSpace = new SpaceBase();
                    newSpace.LocationX = i;
                    newSpace.LocationY = j;
                    _spaces[i, j] = newSpace;
                }
            }

            EventArgs e = new EventArgs();
            this.Loaded(this, e);
        }

        public ISpace GetSpace(int x, int y)
        {
            if (_spaces == null)
                throw new Exception("Gameboard has NOT been loaded");
            return _spaces[x, y];
        }

        public void AddPiece(int x, int y, IPiece piece)
        {
            //check the bounds
            if (!(x >= 0 && x < NumSpacesX) && !(y >= 0 && y < NumSpacesY))
                throw new IndexOutOfRangeException(string.Format("Location is outside of bounds of spaces: {0],{1}",x,y));

            // check that a piece does not already exist at that location
            if (this.GetSpace(x, y).Piece != null)
                throw new Exception("A piece already exists at that space");
            ((SpaceBase)this.GetSpace(x, y)).Piece = piece;
            piece.PieceSpace = (SpaceBase)this.GetSpace(x, y);

            PieceAddedEventArgs pieceAddedEventArgs = new PieceAddedEventArgs(x, y, piece);
            PieceAdded(this, pieceAddedEventArgs);
        }
        public void MovePiece(int x1, int y1, int x2, int y2)
        {
            IPiece pieceToMove = GetSpace(x1, y1).Piece;
            this.MovePiece(pieceToMove, x2, y2);
        }
        public void MovePiece(IPiece pieceToMove, int x2, int y2)
        {
            // add check that a piece is there
            if (pieceToMove == null)
                throw new Exception("Piece must exist at initial location");
            // if a piece exists at the destination location, throw an exception
            SpaceBase secondSpace = (SpaceBase)GetSpace(x2, y2);
            if (secondSpace.Piece != null)
                throw new Exception("Piece must NOT exist at destination location");

            SpaceBase space = (SpaceBase)pieceToMove.PieceSpace;
            space.Piece = null;
            secondSpace.Piece = pieceToMove;
            pieceToMove.PieceSpace = ((SpaceBase)GetSpace(x2, y2));

            PieceMovedEventArgs pieceMovedEventArgs = new PieceMovedEventArgs(space.LocationX, space.LocationY, x2, y2, pieceToMove);
            PieceMoved(this, pieceMovedEventArgs);
        }
        public void SelectSpace(ISpace space)
        {
            this.SelectedSpace = space;
            SpaceSelectedEventArgs e = new SpaceSelectedEventArgs(space);
            SpaceSelected(this, e);
        }
        public void ClearSelectedSpace()
        {
            this.SelectedSpace = null;
            SelectedSpaceCleared(this, new SelectedSpaceClearedEventArgs());
        }
        public bool CanMoveToSpace(int x, int y)
        {
            // If there is a space selected and the destination space does NOT contain a piece, then move that piece to the clicked space
            ISpace destinationSpace = this.GetSpace(x,y);
            if (this.SelectedSpace != null && destinationSpace.Piece == null)
                return true;
            return false;
        }

        public int NumSpacesX { get; private set; }
        public int NumSpacesY { get; private set; }
        public ISpace SelectedSpace { get; private set; }

        public event EventHandler Loaded;
        void GameBoardBase_Loaded(object sender, EventArgs e)
        {
            //do nothing    
        }

        public event PieceAddedEventHandler PieceAdded;
        void GameBoardBase_PieceAdded(object sender, PieceAddedEventArgs e)
        {
        }

        public event PieceMovedEventHandler PieceMoved;
        void GameBoardBase_PieceMoved(object sender, PieceMovedEventArgs e)
        {}

        public event SpaceSelectedEventHandler SpaceSelected;
        void GameBoardBase_SpaceSelected(object sender, SpaceSelectedEventArgs e)
        { }

        public event SelectedSpaceClearedEventHandler SelectedSpaceCleared;
        void GameBoardBase_SelectedSpaceCleared(object sender, SelectedSpaceClearedEventArgs e)
        {
        }

    }

    public delegate void PieceAddedEventHandler(object sender, PieceAddedEventArgs e);
    public class PieceAddedEventArgs : EventArgs
    {
        internal PieceAddedEventArgs(int locationX, int locationY, IPiece piece)
        {
            LocationX = locationX;
            LocationY = locationY;
            Piece = piece;
        }

        public int LocationX { get; private set; }
        public int LocationY { get; private set; }
        public IPiece Piece { get; private set; }
    }

    public delegate void PieceMovedEventHandler(object sender, PieceMovedEventArgs e);
    public class PieceMovedEventArgs : EventArgs
    {
        internal PieceMovedEventArgs(int locationX1, int locationY1, int locationX2, int locationY2, IPiece piece)
        {
            LocationX1 = locationX1;
            LocationY1 = locationY1;
            LocationX2 = locationX2;
            LocationY2 = locationY2;
            Piece = piece;
        }

        public int LocationX1 { get; private set; }
        public int LocationY1 { get; private set; }
        public int LocationX2 { get; private set; }
        public int LocationY2 { get; private set; }
        public IPiece Piece { get; private set; }
    }

    public delegate void SpaceSelectedEventHandler(object sender, SpaceSelectedEventArgs e);
    public class SpaceSelectedEventArgs : EventArgs
    {
        internal SpaceSelectedEventArgs(ISpace space)
        {
            Space = space;
        }

        public ISpace Space { get; private set; }
    }

    public delegate void SelectedSpaceClearedEventHandler(object sender, SelectedSpaceClearedEventArgs e);
    public class SelectedSpaceClearedEventArgs : EventArgs
    {
        internal SelectedSpaceClearedEventArgs()
        {
        }
    }

}
