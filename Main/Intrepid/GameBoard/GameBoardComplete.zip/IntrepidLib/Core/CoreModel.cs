﻿using System;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using IntrepidLib.Cover;

namespace IntrepidLib.Core
{
    public class CoreModel
    {
        public CoreModel()
        {
            CoreGameBoardFactory = new GameBoardFactory();
        }

        public GameBoardFactory CoreGameBoardFactory { get; private set; }
    }
}
