﻿using System;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;

using Microsoft.VisualStudio.TestTools.UnitTesting;
using IntrepidLib.Cover;
using System.Collections.Generic;

namespace Intrepid.Test
{
    //[TestClass]    
    public class CoverTests
    {
        [TestMethod]
        public void Setup_GetIGameBoardFromFactory()
        {
            IGameBoard myGameBoard = (new GameBoardFactory()).CreateGameBoard(null);
            Assert.IsNotNull(myGameBoard);
        }

        /// <summary>
        /// After calling Load, the gameboardLoaded event should have fired
        /// </summary>
        [TestMethod]
        public void Setup_FireLoadedEventHandler()
        {
            IGameBoard myGameBoard = (new GameBoardFactory()).CreateGameBoard(null);
            bool gameboardLoaded = false;
            myGameBoard.Loaded += 
                delegate(object sender, EventArgs e) 
                {
                    gameboardLoaded = true;
                };
            myGameBoard.Load();
            Assert.IsTrue(gameboardLoaded, "GameBoard Loaded Event did NOT fire");
        }

        /// <summary>
        /// Initialize the gameboard using the settings for numSpaces
        /// After calling Load, the gameboard should load with the number of
        /// horizontal and vertical spaces specified in the initial parameters
        /// </summary>
        [TestMethod]
        public void Setup_LoadNumSpaces()
        {
            int numSpacesX = 5;
            int numSpacesY = 6;
            List<ISpace> colTrackSpaces = new List<ISpace>();   //to track that all spaces are different

            Dictionary<string, object> gameboardSettings = new Dictionary<string, object>();
            gameboardSettings.Add(GameBoardFactory.GameBoardSettings.NumSpacesX, numSpacesX);
            gameboardSettings.Add(GameBoardFactory.GameBoardSettings.NumSpacesY, numSpacesY);

            IGameBoard myGameBoard = (new GameBoardFactory()).CreateGameBoard(gameboardSettings);
            myGameBoard.Load();
            Assert.AreEqual<int>(numSpacesX, myGameBoard.NumSpacesX);
            Assert.AreEqual<int>(numSpacesY, myGameBoard.NumSpacesY);
            // should be able to iterate through each space and verify it's NOT null
            for (int i = 0; i < numSpacesX; i++)
            {
                for (int j = 0; j < numSpacesY; j++)
                {
                    ISpace mySpace = myGameBoard.GetSpace(i,j);
                    Assert.IsNotNull(mySpace);
                    Assert.IsFalse(colTrackSpaces.Contains(mySpace));
                    colTrackSpaces.Add(mySpace);
                }
            }
        }

        /// <summary>
        /// Initialize the gameboard using the settings for numSpaces
        /// If I get the same space twice, the two should equal each other
        /// </summary>
        [TestMethod]
        public void Space_GetSameSpace()
        {
            int numSpacesX = 5;
            int numSpacesY = 6;
            List<ISpace> colTrackSpaces = new List<ISpace>();   //to track that all spaces are different

            Dictionary<string, object> gameboardSettings = new Dictionary<string, object>();
            gameboardSettings.Add(GameBoardFactory.GameBoardSettings.NumSpacesX, numSpacesX);
            gameboardSettings.Add(GameBoardFactory.GameBoardSettings.NumSpacesY, numSpacesY);

            IGameBoard myGameBoard = (new GameBoardFactory()).CreateGameBoard(gameboardSettings);
            myGameBoard.Load();
            for (int i = 0; i < numSpacesX; i++)
            {
                for (int j = 0; j < numSpacesY; j++)
                {
                    ISpace spaceA = myGameBoard.GetSpace(i, j);
                    ISpace spaceB = myGameBoard.GetSpace(i, j);
                    Assert.IsTrue(spaceA == spaceB);
                }
            }
        }

        /// <summary>
        /// Initialize the gameboard using the settings for numSpaces
        /// Test calling getspace before loading.  Should throw exception
        /// </summary>
        [TestMethod]
        [ExpectedException(typeof(Exception))]
        public void Space_GetSpaceBeforeLoad()
        {
            int numSpacesX = 5;
            int numSpacesY = 6;
            List<ISpace> colTrackSpaces = new List<ISpace>();   //to track that all spaces are different

            Dictionary<string, object> gameboardSettings = new Dictionary<string, object>();
            gameboardSettings.Add(GameBoardFactory.GameBoardSettings.NumSpacesX, numSpacesX);
            gameboardSettings.Add(GameBoardFactory.GameBoardSettings.NumSpacesY, numSpacesY);

            IGameBoard myGameBoard = (new GameBoardFactory()).CreateGameBoard(gameboardSettings);
            myGameBoard.GetSpace(5, 6);
        }

        /// <summary>
        /// Initialize the gameboard using the settings for numSpaces
        /// Add a piece and expect the event
        /// </summary>
        [TestMethod]
        public void Add_AddPiece()
        {
            int numSpacesX = 5;
            int numSpacesY = 6;
            int pieceLocationX = 3;
            int pieceLocationY = 3;

            Dictionary<string, object> gameboardSettings = new Dictionary<string, object>();
            gameboardSettings.Add(GameBoardFactory.GameBoardSettings.NumSpacesX, numSpacesX);
            gameboardSettings.Add(GameBoardFactory.GameBoardSettings.NumSpacesY, numSpacesY);

            IGameBoard myGameBoard = (new GameBoardFactory()).CreateGameBoard(gameboardSettings);
            myGameBoard.Load();

            bool pieceAdded = false;

            myGameBoard.PieceAdded += delegate
            {
                pieceAdded = true;
            };

            // add a piece to the gameboard
            string strPiece = "Hello World";
            myGameBoard.AddPiece(pieceLocationX, pieceLocationY, (new GameBoardFactory()).CreatePiece(strPiece));
            Assert.IsTrue(pieceAdded);

        }

        /// <summary>
        /// Initialize the gameboard using the settings for numSpaces
        /// Add a piece and expect the event
        /// </summary>
        [TestMethod]
        public void Add_AddPieceCheckLocation()
        {
            int numSpacesX = 5;
            int numSpacesY = 6;
            int pieceLocationX = 3;
            int pieceLocationY = 4;

            Dictionary<string, object> gameboardSettings = new Dictionary<string, object>();
            gameboardSettings.Add(GameBoardFactory.GameBoardSettings.NumSpacesX, numSpacesX);
            gameboardSettings.Add(GameBoardFactory.GameBoardSettings.NumSpacesY, numSpacesY);

            IGameBoard myGameBoard = (new GameBoardFactory()).CreateGameBoard(gameboardSettings);
            myGameBoard.Load();
            myGameBoard.PieceAdded += new PieceAddedEventHandler(AddPieceCheckLocationHelper);

            // add a piece to the gameboard
            string strPiece = "Hello World";
            myGameBoard.AddPiece(pieceLocationX, pieceLocationY, (new GameBoardFactory()).CreatePiece(strPiece));
        }
        private void AddPieceCheckLocationHelper(object sender, PieceAddedEventArgs e)
        {
            Assert.AreEqual<int>(3, e.LocationX, "X Location does not match");
            Assert.AreEqual<int>(4, e.LocationY,"Y Location does not match");
        }

        /// <summary>
        /// Initialize the gameboard using the settings for numSpaces
        /// Add a piece to the same locatino twice.  Should get an error that a piece already exists
        /// </summary>
        [TestMethod]
        [ExpectedException(typeof(Exception))]
        public void Add_AddPieceTwice()
        {
            int numSpacesX = 5;
            int numSpacesY = 6;
            int pieceLocationX = 3;
            int pieceLocationY = 4;

            Dictionary<string, object> gameboardSettings = new Dictionary<string, object>();
            gameboardSettings.Add(GameBoardFactory.GameBoardSettings.NumSpacesX, numSpacesX);
            gameboardSettings.Add(GameBoardFactory.GameBoardSettings.NumSpacesY, numSpacesY);

            IGameBoard myGameBoard = (new GameBoardFactory()).CreateGameBoard(gameboardSettings);
            myGameBoard.Load();
            myGameBoard.PieceAdded += new PieceAddedEventHandler(AddPieceCheckLocationHelper);

            // add a piece to the gameboard
            string strPiece = "Hello World";
            myGameBoard.AddPiece(pieceLocationX, pieceLocationY, (new GameBoardFactory()).CreatePiece(strPiece));
            myGameBoard.AddPiece(pieceLocationX, pieceLocationY, (new GameBoardFactory()).CreatePiece(strPiece));
        }

        /// <summary>
        /// Initialize the gameboard using the settings for numSpaces
        /// Add a piece to a location that does NOT exist on the board
        /// </summary>
        [TestMethod]
        [ExpectedException(typeof(IndexOutOfRangeException))]
        public void Add_AddPieceOutOfBounds()
        {
            int numSpacesX = 5;
            int numSpacesY = 6;
            int pieceLocationX = 7;
            int pieceLocationY = 3;

            Dictionary<string, object> gameboardSettings = new Dictionary<string, object>();
            gameboardSettings.Add(GameBoardFactory.GameBoardSettings.NumSpacesX, numSpacesX);
            gameboardSettings.Add(GameBoardFactory.GameBoardSettings.NumSpacesY, numSpacesY);

            IGameBoard myGameBoard = (new GameBoardFactory()).CreateGameBoard(gameboardSettings);
            myGameBoard.Load();
            myGameBoard.PieceAdded += new PieceAddedEventHandler(AddPieceCheckLocationHelper);

            // add a piece to the gameboard
            string strPiece = "Hello World";
            myGameBoard.AddPiece(pieceLocationX, pieceLocationY, (new GameBoardFactory()).CreatePiece(strPiece));
        }

        /// <summary>
        /// Initialize the gameboard using the settings for numSpaces
        /// Add a piece and move it to a different location
        /// </summary>
        [TestMethod]
        public void Move_MovePiece()
        {
            int numSpacesX = 5;
            int numSpacesY = 6;
            int pieceLocationX1 = 0;
            int pieceLocationY1 = 0;
            int pieceLocationX2 = 4;
            int pieceLocationY2 = 5;

            Dictionary<string, object> gameboardSettings = new Dictionary<string, object>();
            gameboardSettings.Add(GameBoardFactory.GameBoardSettings.NumSpacesX, numSpacesX);
            gameboardSettings.Add(GameBoardFactory.GameBoardSettings.NumSpacesY, numSpacesY);

            IGameBoard myGameBoard = (new GameBoardFactory()).CreateGameBoard(gameboardSettings);
            myGameBoard.Load();

            // add a piece to the gameboard
            string strPiece = "Hello World";
            IPiece pieceToAdd = (new GameBoardFactory()).CreatePiece(strPiece);
            myGameBoard.AddPiece(pieceLocationX1, pieceLocationY1, pieceToAdd);
            Assert.AreEqual(pieceToAdd, myGameBoard.GetSpace(pieceLocationX1, pieceLocationY1).Piece);
            //now move it
            myGameBoard.MovePiece(pieceLocationX1, pieceLocationY1, pieceLocationX2, pieceLocationY2);
            // check the original location is null and that the new location contains our piece
            Assert.IsNull(myGameBoard.GetSpace(pieceLocationX1, pieceLocationY1).Piece);
            Assert.AreEqual(pieceToAdd, myGameBoard.GetSpace(pieceLocationX2, pieceLocationY2).Piece);
        }

        /// <summary>
        /// Initialize the gameboard using the settings for numSpaces
        /// Attempt to move a piece that's not there
        /// </summary>
        [TestMethod]
        [ExpectedException(typeof(Exception))]
        public void Move_MovePieceNotThere()
        {
            int numSpacesX = 5;
            int numSpacesY = 6;
            int pieceLocationX1 = 0;
            int pieceLocationY1 = 0;
            int pieceLocationX2 = 4;
            int pieceLocationY2 = 5;

            Dictionary<string, object> gameboardSettings = new Dictionary<string, object>();
            gameboardSettings.Add(GameBoardFactory.GameBoardSettings.NumSpacesX, numSpacesX);
            gameboardSettings.Add(GameBoardFactory.GameBoardSettings.NumSpacesY, numSpacesY);

            IGameBoard myGameBoard = (new GameBoardFactory()).CreateGameBoard(gameboardSettings);
            myGameBoard.Load();

            //call move piece
            myGameBoard.MovePiece(pieceLocationX1, pieceLocationY1, pieceLocationX2, pieceLocationY2);
        }

        /// <summary>
        /// Move piece should fire PieceMoved event args
        /// </summary>
        [TestMethod]
        public void Move_MovePieceFireEvent()
        {
            int numSpacesX = 5;
            int numSpacesY = 6;
            int pieceLocationX1 = 0;
            int pieceLocationY1 = 0;
            int pieceLocationX2 = 4;
            int pieceLocationY2 = 5;

            Dictionary<string, object> gameboardSettings = new Dictionary<string, object>();
            gameboardSettings.Add(GameBoardFactory.GameBoardSettings.NumSpacesX, numSpacesX);
            gameboardSettings.Add(GameBoardFactory.GameBoardSettings.NumSpacesY, numSpacesY);

            IGameBoard myGameBoard = (new GameBoardFactory()).CreateGameBoard(gameboardSettings);
            bool pieceMoved = false;
            myGameBoard.PieceMoved += delegate
                {
                       pieceMoved = true;
                };
            myGameBoard.PieceMoved += new PieceMovedEventHandler(myGameBoard_PieceMovedHelper);
            myGameBoard.Load();

            //call move piece
            string strPiece = "Hello World";
            myGameBoard.AddPiece(pieceLocationX1, pieceLocationY1, (new GameBoardFactory()).CreatePiece(strPiece));
            myGameBoard.MovePiece(pieceLocationX1, pieceLocationY1, pieceLocationX2, pieceLocationY2);
            Assert.IsTrue(pieceMoved);
        }
        void myGameBoard_PieceMovedHelper(object sender, PieceMovedEventArgs e)
        {
            Assert.AreEqual(e.LocationX1, 0);
            Assert.AreEqual(e.LocationY1, 0);
            Assert.AreEqual(e.LocationX2, 4);
            Assert.AreEqual(e.LocationY2, 5);
        }

        /// <summary>
        /// Select a piece
        /// Piece Selected event should be fired
        /// </summary>
        [TestMethod]
        public void Select_SelectSpaceFireEvent()
        {
            int numSpacesX = 5;
            int numSpacesY = 6;
            int pieceLocationX = 2;
            int pieceLocationY = 2;

            Dictionary<string, object> gameboardSettings = new Dictionary<string, object>();
            gameboardSettings.Add(GameBoardFactory.GameBoardSettings.NumSpacesX, numSpacesX);
            gameboardSettings.Add(GameBoardFactory.GameBoardSettings.NumSpacesY, numSpacesY);

            IGameBoard myGameBoard = (new GameBoardFactory()).CreateGameBoard(gameboardSettings);
            bool spaceSelected = false;
            myGameBoard.SpaceSelected += delegate
            {
                spaceSelected = true;
            };
            myGameBoard.SpaceSelected += new SpaceSelectedEventHandler(myGameBoard_SpaceSelectedHelper);
            myGameBoard.Load();

            ISpace getSpace = myGameBoard.GetSpace(pieceLocationX, pieceLocationY);
            myGameBoard.SelectSpace(getSpace);
            Assert.IsTrue(spaceSelected);
        }
        void myGameBoard_SpaceSelectedHelper(object sender, SpaceSelectedEventArgs e)
        {
            Assert.AreEqual(e.Space.LocationX, 2);
            Assert.AreEqual(e.Space.LocationY, 2);
        }
    }
}
