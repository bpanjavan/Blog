﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Xml.Linq;

namespace Silverlight_FileUploadCustom.Web
{
    public partial class _Default : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            XDocument xdocContentTypeMap = XDocument.Load(Server.MapPath(@"XML\ContentTypeMap.xml"));
            IEnumerable<XElement> xElements = xdocContentTypeMap.Element(XName.Get("ContentTypeMap")).Elements("ContentType");
            var xmlnodelistContentTypesMatch = from xmlnode in xElements
                                               where xmlnode.Attribute(XName.Get("Extension")).Value == "jpg"
                                               select xmlnode;
            XElement xmlnodeContentTypeMatch = xmlnodelistContentTypesMatch.First<XElement>();
                
        }
    }
}
