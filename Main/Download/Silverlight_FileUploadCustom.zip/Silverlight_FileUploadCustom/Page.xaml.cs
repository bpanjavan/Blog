﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using System.IO;
using System.Xml;

using Silverlight_FileUploadCustom.FileRouter;
using System.Text;
using System.Threading;
using System.Windows.Threading;
using Silverlight_FileUploadCustom.UserControls;

namespace Silverlight_FileUploadCustom
{
    public partial class Page : UserControl
    {

#region Variables
        protected ModalLoading modalloadingFileLinkList;        // Modal Loading User Control
        private int fileLimit = 3;                              // File limit for uploading
        FileRouter.FileRouterHeadSoap fileRouterClient = null;  // Web service proxy
        List<FileListItem> colFileListItem = null;              // Our collection of files to upload
        int numFilesOutstanding = 0;                                

        private DispatcherTimer uploadButtonTimer;  // timer to monitor whether to enable the upload button
        private DispatcherTimer deleteButtonTimer;  // timer to monitor whether to enable the delete button
        DispatcherTimer deleteTimer = null;         // timer to monitor status of Delete All operation
        DispatcherTimer uploadTimer = null;         // timer to monitor status of upload operation

        bool areWeUploading = false;            // Whether we are in the middle of uploading files
        string fileSaveResult = string.Empty;   // The result response from the FileRouter web service
        string fileSaveStatus = string.Empty;   // Status returned from the FileRouter web service
        List<string> fileNameList = null;       // List of file names retreived back from the web service
        List<string> fileIDList = null;         // List of ID's retrieved from the web service

        UploadStatus fileUploadedStatus = 
                                UploadStatus.NotStarted;    // The current status of Uploading
        string fileUploadStatusError = string.Empty;        // If there was an error, this contains the message
        DeletingStatus finishedDeletingStatus = 
                                DeletingStatus.NotStarted;  // The current status of deleting
        String finishedDeletingError = string.Empty;        // If there was an error, this contains the message

#endregion Variables

#region Enumerations
        /// <summary>
        /// Enumeration for the status of the Delete All Operation
        /// </summary>
        public enum DeletingStatus
        {
            NotStarted,
            Deleting,
            Finished,
            Error
        }

        /// <summary>
        /// Enumeration for the status of the Upload status
        /// </summary>
        public enum UploadStatus
        {
            NotStarted,
            Uploading,
            Finished,
            Error
        }
#endregion Enumerations

#region Properties
        /// <summary>
        /// This is set by the aspx page that serves this control up.
        /// This is the partial path pointing to our File Reader custom handler
        /// </summary>
        public string CustomReaderPath { get; set; }
#endregion Properties

#region Page Events
        public Page()
        {
            InitializeComponent();
            fileRouterClient = new FileRouter.FileRouterHeadSoapClient();
        }

        /// <summary>
        /// Page Load Event Handler
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void Page_Loaded(object sender, RoutedEventArgs e)
        {
            // Set the default URI of the CustomReaderPath.  This points to the handler to output files uploaded
            textblockStatus.Text = CustomReaderPath;
            hyperlinkbuttonFileReader.NavigateUri = new Uri(CustomReaderPath);

            // Initialize the UploadButton timer.  This timer is constantly monitoring the conditions whether to
            //  enable the upload button
            uploadButtonTimer = new DispatcherTimer();
            uploadButtonTimer.Interval = new TimeSpan(1);
            uploadButtonTimer.Tick += new EventHandler(uploadButtonTimer_Tick);
            uploadButtonTimer.Start();

            // Initialize the DeleteButton timer.  This timer is constantly monitoring the conditions whether to enabled
            //  the delete (remove) button
            deleteButtonTimer = new DispatcherTimer();
            deleteButtonTimer.Interval = new TimeSpan(1);
            deleteButtonTimer.Tick += new EventHandler(deleteButtonTimer_Tick);
            deleteButtonTimer.Start();

            // add the modal loading control.  I attempted to add this at design time and the designer choked
            modalloadingFileLinkList = new ModalLoading();
            modalloadingFileLinkList.Visibility = Visibility.Visible;
            modalloadingFileLinkList.SetValue(Grid.RowSpanProperty, 2);
            gridFileLinkList.Children.Add(modalloadingFileLinkList);
        }
#endregion Page Events

#region Event Handlers
        /// <summary>
        /// Handles the "Add" Button event.
        /// Opens a new OpenFialDialog for the user to select files to add to the main file list
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void buttonBrowse_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                OpenFileDialog dlg = new OpenFileDialog();
                dlg.Filter = "All Files (*.*)|*.*|PDFs(*.pdf)|*.pdf|Images(*.jpg,*.gif)|*.jpg;*.gif";
                dlg.Multiselect = true;

                if (dlg.ShowDialog() == false)
                    return;

                // ONLY if it's null, create a new FileListItem list 
                // Add all of our FileInfo items to it
                bool firstTime = false;
                if (colFileListItem == null)
                {
                    colFileListItem = new List<FileListItem>();
                    firstTime = true;
                }
                listboxFileInfoList.ItemsSource = null;
                foreach (FileInfo fileInfo in dlg.Files)
                {
                    // if file is more than 300 kb then do NOT add it
                    int limitSize = 1024 * 300;
                    if (fileInfo.Length > limitSize)
                    {
                        MessageBox.Show("File: " + fileInfo.Name
                            + " is greater than 300 kbs.  File will not be added");
                    }
                    else
                    {
                        colFileListItem.Add(new FileListItem()
                        {
                            Name = fileInfo.Name,
                            IsSelected = false,
                            FileInfo = fileInfo
                        });
                    }
                }

                listboxFileInfoList.ItemsSource = colFileListItem;//dlg.Files;
                ((Storyboard)this.Resources["storyboardShiftToFileList"]).Begin();
                if (firstTime)
                    MessageBox.Show("Select up to 3 files to upload");

            }
            catch (Exception ex)
            {
                textblockStatus.Text = ex.Message;
            }

        }
        
        /// <summary>
        /// Handles the Upload button event.
        /// Puts together an XML FileRouterPacket and calls the WCF web service FileRouter.
        /// The first packet command sent to the web service is a command to delete all files in the database.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void buttonUpload_Click(object sender, RoutedEventArgs e)
        {
            // Validate
            // They cannot select more than 3 files to upload
            IEnumerable<FileInfo> colFileInfo = from fileListItem in colFileListItem
                                                where fileListItem.IsSelected == true
                                                select fileListItem.FileInfo;
            if (colFileInfo.Count<FileInfo>() > fileLimit)
            {
                MessageBox.Show(string.Format("Please select no more than {0} files", fileLimit));
                return;
            }

            if (listboxFileInfoList.ItemsSource == null)
                return;

            ((Storyboard)this.Resources["storyboardShiftToOutput"]).Begin();
            listboxFileLinkList.ItemsSource = null;
            //gridFileLinkList.Visibility = Visibility.Collapsed;
            areWeUploading = true;
            modalloadingFileLinkList.Visibility = Visibility.Visible;
            buttonShiftToFileList.Visibility = Visibility.Collapsed;

            // First send a command to delete all files in the database
            finishedDeletingStatus = DeletingStatus.Deleting;
            FileRouter.DeleteAllRequest deleteAllRequest = new DeleteAllRequest(new DeleteAllRequestBody());
            deleteAllRequest.Body.filePacket = "<FileRouterPacket><Head><Status></Status></Head></FileRouterPacket>";
            AsyncCallback deleteCallback = new AsyncCallback(ProcessDeleteAllResponse);
            fileRouterClient.BeginDeleteAll(deleteAllRequest, deleteCallback, null);
            deleteTimer = new DispatcherTimer();
            deleteTimer.Interval = new TimeSpan(1);
            deleteTimer.Tick += new EventHandler(deleteTimer_Tick);
            deleteTimer.Start();
        }

        /// <summary>
        /// Implements the standard "Select All" functionality on our File List
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void checkboxSelectAll_Click(object sender, RoutedEventArgs e)
        {
            if (colFileListItem == null)
                return;

            CheckBox checkboxSelectAll = (CheckBox)sender;
            foreach (FileListItem fileListItem in colFileListItem)
            {
                fileListItem.IsSelected = checkboxSelectAll.IsChecked.Value;
            }
            listboxFileInfoList.ItemsSource = null;
            listboxFileInfoList.ItemsSource = colFileListItem;
        }

        /// <summary>
        /// Shift from our Uploaded Files list back to our initial File List.
        /// This is done through a storyboard animation
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void buttonShiftToFileList_Click(object sender, RoutedEventArgs e)
        {
            ((Storyboard)this.Resources["storyboardShiftToFileList"]).Begin();
        }

        /// <summary>
        /// Shift from our initial File List to our Upload File List.
        /// This is done through a storyboard animation
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void buttonShiftToUploadList_Click(object sender, RoutedEventArgs e)
        {
            ((Storyboard)this.Resources["storyboardShiftToOutput"]).Begin();
        }

        /// <summary>
        /// Delete (remove) button event handler.  Removes any selected File from the list.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void buttonDelete_Click(object sender, RoutedEventArgs e)
        {
            // Confirm they want to delete
            MessageBoxResult result = MessageBox.Show("Are you sure you want to remove the selected files?", "Confirm remove", MessageBoxButton.OKCancel);

            //if they said cancel then exit
            if (result.ToString() != "OK")
                return;

            //Otherwise, remove selected files from list
            listboxFileInfoList.ItemsSource = null;
            int i = 0;
            while (i < colFileListItem.Count)
            {
                if (colFileListItem[i].IsSelected == true)
                {
                    colFileListItem.Remove(colFileListItem[i]);
                }
                else
                    i++;

            }
            listboxFileInfoList.ItemsSource = colFileListItem;
        }
#endregion

#region Timer Events
        /// <summary>
        /// Tick event handler.  Determines whether to enable upload button based on several factors
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        void uploadButtonTimer_Tick(object sender, EventArgs e)
        {
            // enable upload if at least one item is checked and we're NOT uploading
            if (colFileListItem == null)
            {
                buttonUpload.IsEnabled = false;
                return;
            }
            IEnumerable<FileInfo> colFileInfo = from fileListItem in colFileListItem
                                                where fileListItem.IsSelected == true
                                                select fileListItem.FileInfo;

            buttonUpload.IsEnabled = colFileInfo.Count<FileInfo>() > 0 && !areWeUploading;
        }

        /// <summary>
        /// Tick event handler.  Determines whether to enable delete (remove) button based on several factors
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        void deleteButtonTimer_Tick(object sender, EventArgs e)
        {
            // enable delete if at least one item is checked
            if (colFileListItem == null)
            {
                buttonDelete.IsEnabled = false;
                return;
            }
            IEnumerable<FileInfo> colFileInfo = from fileListItem in colFileListItem
                                                where fileListItem.IsSelected == true
                                                select fileListItem.FileInfo;
            buttonDelete.IsEnabled = colFileInfo.Count<FileInfo>() > 0;
        }

        /// <summary>
        /// After the call to the WCF service to delete all files, this is constantly checking
        ///   if the request has been completed.  If so, call UploadFiles()
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        void deleteTimer_Tick(object sender, EventArgs e)
        {
            if (finishedDeletingStatus == DeletingStatus.Finished)
            {

                deleteTimer.Stop();
                UploadFiles();
            }
            else if (finishedDeletingStatus == DeletingStatus.Error)
            {
                deleteTimer.Stop();
                MessageBox.Show(finishedDeletingError);
            }

        }

        /// <summary>
        /// Upload timer, constantly checks to see if all files have finished uploading
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        void uploadTimer_Tick(object sender, EventArgs e)
        {
            if (fileUploadedStatus == UploadStatus.Finished)
            {
                uploadTimer.Stop();
                uploadTimer = null;
                if (fileSaveStatus == "ERROR")
                    MessageBox.Show(fileSaveStatus);

                // construct the list of LinkItems and bind to the listbox
                List<LinkItem> colLinkItem = new List<LinkItem>();
                for (int i = 0; i < fileIDList.Count; i++)
                {
                    colLinkItem.Add(new LinkItem()
                    {
                        Name = fileNameList[i],
                        URL = CustomReaderPath + fileIDList[i]
                    });
                }

                areWeUploading = false;

                listboxFileLinkList.ItemsSource = colLinkItem;
                buttonShiftToUploadList.Visibility = Visibility.Visible;
                buttonShiftToFileList.Visibility = Visibility.Visible;

                //gridFileLinkList.Visibility = Visibility.Visible;
                modalloadingFileLinkList.Visibility = Visibility.Collapsed;

                //StringBuilder sbFileList = new StringBuilder();
                //foreach (string fileID in fileIDList)
                //    sbFileList.AppendLine(fileID);
                //textboxOutput.Text = sbFileList.ToString();              
            }
            else if (fileUploadedStatus == UploadStatus.Error)
            {
                uploadTimer.Stop();
                MessageBox.Show(fileUploadStatusError);
            }
        }
#endregion Timer Events

#region Process Web Service Responses
        /// <summary>
        /// Processes File Save Response.  Check the status to see if files were saved successfully and
        ///   updates the variable fileUploadedStatus to indicate so
        /// </summary>
        /// <param name="result"></param>
        void ProcessFileSaveResponse(IAsyncResult result)
        {
            try
            {
                FileSaveResponse fileSaveResponse = fileRouterClient.EndFileSave(result);
                string resultPacket = fileSaveResponse.Body.FileSaveResult;
                using (StringReader sr = new StringReader(resultPacket))
                {
                    using (XmlReader xReader = XmlReader.Create(sr))
                    {
                        while (xReader.Name != "Status")
                            xReader.Read();
                        xReader.Read();     //read it one more time to get the value
                        fileSaveStatus = xReader.Value;

                        // keep reading to get the file ID
                        while (xReader.Name != "FileId")
                            xReader.Read();
                        xReader.Read();
                        fileIDList.Add(xReader.Value);

                        // keep reading to get the file name
                        while (xReader.Name != "FileName")
                            xReader.Read();
                        xReader.Read();
                        fileNameList.Add(xReader.Value);

                        // but if one of them failed, then we need to stop the whole thing                  

                        numFilesOutstanding--;
                        if (numFilesOutstanding == 0)
                            fileUploadedStatus = UploadStatus.Finished;
                    }
                }
                fileSaveResult = resultPacket;
            }
            catch (Exception ex)
            {
                StringBuilder sbError = new StringBuilder();
                sbError.AppendLine("Error: PLEASE REFRESH THE PAGE");
                sbError.AppendLine(string.Empty);
                sbError.AppendLine("Type: " + ex.GetType().ToString());
                sbError.AppendLine("Message: " + ex.Message);
                sbError.AppendLine("StackTrace: " + ex.StackTrace);
                fileUploadedStatus = UploadStatus.Error;
                fileUploadStatusError = sbError.ToString();
            }
        }

        /// <summary>
        /// Processes Delete All Response.  Check the status to see if files were deleted successfully and
        ///   updates the variable finishedDeleting to indicate so
        /// </summary>
        /// <param name="result"></param>
        void ProcessDeleteAllResponse(IAsyncResult result)
        {
            try
            {
                string deleteAllStatus = string.Empty;
                DeleteAllResponse deleteAllResponse = fileRouterClient.EndDeleteAll(result);
                string resultPacket = deleteAllResponse.Body.DeleteAllResult;
                using (StringReader sr = new StringReader(resultPacket))
                {
                    using (XmlReader xReader = XmlReader.Create(sr))
                    {
                        while (xReader.Name != "Status")
                            xReader.Read();
                        xReader.Read();     //read it one more time to get the value
                        deleteAllStatus = xReader.Value;

                        if (deleteAllStatus != "SUCCESS")
                            MessageBox.Show("ERROR");
                        else
                            finishedDeletingStatus = DeletingStatus.Finished;
                    }
                }
            }
            catch (Exception ex)
            {
                StringBuilder sbError = new StringBuilder();
                sbError.AppendLine("Error");
                sbError.AppendLine("Type: " + ex.GetType().ToString());
                sbError.AppendLine("Message: " + ex.Message);
                sbError.AppendLine("StackTrace: " + ex.StackTrace);
                finishedDeletingStatus = DeletingStatus.Error;
                finishedDeletingError = sbError.ToString();
            }
        }
#endregion Process Web Service Responses

        /// <summary>
        /// Called after the Delete All responses has been processed.
        /// For each file to be uploaded, constructs the XML FileRouterPacket to use to call the web service,
        ///     then calls the web service to save the file.
        /// </summary>
        private void UploadFiles()
        {
            try
            {
                //IEnumerable<FileInfo> colFileInfo = (IEnumerable<FileInfo>)listboxFileInfoList.ItemsSource;
                IEnumerable<FileInfo> colFileInfo = from fileListItem in colFileListItem
                                                    where fileListItem.IsSelected == true
                                                    select fileListItem.FileInfo;

                fileIDList = new List<string>();
                fileNameList = new List<string>();
                fileUploadedStatus = UploadStatus.Uploading;

                foreach (FileInfo fileInfo in colFileInfo)
                {
                    string fileString = string.Empty;
                    byte[] fileBytes = null;
                    // First get file bytes from File Info Stream
                    using (FileStream fileStream = fileInfo.OpenRead())
                    {
                        fileBytes = new byte[fileStream.Length];
                        fileStream.Read(fileBytes, 0, (int)fileStream.Length);
                        Decoder byteDecoder = Encoding.UTF8.GetDecoder();
                        char[] fileChars = new char[fileBytes.Length];
                        byteDecoder.GetChars(fileBytes, 0, fileBytes.Length, fileChars, 0, true);
                        fileString = new string(fileChars);
                    }


                    StringBuilder sb = new StringBuilder();
                    using (StringWriter stringWriter = new StringWriter(sb))
                    {
                        XmlWriterSettings settings = new XmlWriterSettings();
                        settings.OmitXmlDeclaration = true;
                        using (XmlWriter xmlWriter = XmlWriter.Create(stringWriter, settings))
                        {

                            xmlWriter.WriteStartElement("FileRouterPacket");
                            xmlWriter.WriteStartElement("Head");
                            xmlWriter.WriteStartElement("Status");
                            xmlWriter.WriteEndElement();                // status
                            xmlWriter.WriteStartElement("Message");
                            xmlWriter.WriteEndElement();                // message
                            xmlWriter.WriteEndElement();                // head

                            xmlWriter.WriteStartElement("Body");
                            //xmlWriter.WriteElementString("FileBytes", fileString);

                            //xmlWriter.WriteStartElement("FileBytes");
                            //xmlWriter.WriteCData(fileString);
                            //xmlWriter.WriteEndElement();

                            xmlWriter.WriteStartElement("FileId");
                            xmlWriter.WriteEndElement();                // message
                            xmlWriter.WriteElementString("FileName", fileInfo.Name);
                            xmlWriter.WriteElementString("FileExtension", fileInfo.Extension);
                            xmlWriter.WriteElementString("CreatedOn", DateTime.Now.ToString());
                            xmlWriter.WriteElementString("CreatedBy", "IUser");
                            xmlWriter.WriteElementString("ModifiedOn", DateTime.Now.ToString());
                            xmlWriter.WriteElementString("ModifiedBy", "IUser");
                            xmlWriter.WriteEndElement();                // body

                            xmlWriter.WriteEndElement();
                        }
                    }

                    FileRouter.FileSaveRequest fileSaveRequest = new FileSaveRequest(new FileSaveRequestBody());
                    fileSaveRequest.Body.filePacket = sb.ToString();
                    fileSaveRequest.Body.fileBytes = fileBytes;
                    AsyncCallback callback = new AsyncCallback(ProcessFileSaveResponse);
                    fileRouterClient.BeginFileSave(fileSaveRequest, callback, null);

                    numFilesOutstanding++;
                }

                // If there was more than one, then start the timer
                if (colFileInfo.Count<FileInfo>() > 0)
                {
                    uploadTimer = new DispatcherTimer();
                    uploadTimer.Interval = new TimeSpan(1);
                    uploadTimer.Tick += new EventHandler(uploadTimer_Tick);
                    uploadTimer.Start();
                }
            }
            catch (Exception ex)
            {
                textblockStatus.Text = ex.Message;
                System.Windows.MessageBox.Show(ex.Message);

            }
        }
    }

    /// <summary>
    /// Class to house each of our File List Items in our File List.
    /// </summary>
    public class FileListItem
    {
        public string Name { get; set; }
        public bool IsSelected { get; set; }
        public FileInfo FileInfo { get; set; }
    }

    /// <summary>
    /// Class to house info. to link to an uploaded file.  Used by the Uploaded File List
    /// </summary>
    public class LinkItem
    {
        public string Name { get; set; }
        public string URL { get; set; }
    }
}
