﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;

namespace Silverlight_FileUploadCustom.UserControls
{
    public partial class TriforceAnimation : UserControl
    {
        public double sideLength = 100;

        public TriforceAnimation()
        {
            InitializeComponent();
        }

        private void UserControl_Loaded(object sender, RoutedEventArgs e)
        {
            this.Width = sideLength;
            this.Height = sideLength;

            canvasMain.Width = sideLength;
            canvasMain.Height = sideLength;
            rotatetransformTriforce.CenterX = sideLength / 2;
            rotatetransformTriforce.CenterY = sideLength / 2;

            ellipseMain.Width = sideLength;
            ellipseMain.Height = sideLength;

            double radius = sideLength / 2.0;
            pathfigure0.StartPoint = new Point(radius / 2.0, radius * (1 - Math.Sqrt(3.0) / 2.0));
            polylinesegment0.Points[0] = new Point(radius / 2.0, radius * (1 - Math.Sqrt(3.0) / 2.0));
            polylinesegment0.Points[1] = new Point(radius / 2.0, radius);
            polylinesegment0.Points[2] = new Point(radius * 5.0 / 4.0, radius * (1 - Math.Sqrt(3.0) / 4.0));

            pathfigure1.StartPoint = new Point(radius / 2.0, radius);
            polylinesegment1.Points[0] = new Point(radius / 2.0, radius);
            polylinesegment1.Points[1] = new Point(radius / 2.0, radius * (1 + Math.Sqrt(3.0) / 2.0));
            polylinesegment1.Points[2] = new Point(radius * 5.0 / 4.0, radius * (1 + Math.Sqrt(3.0) / 4.0));

            pathfigure2.StartPoint = new Point(radius * 5.0 / 4.0, radius * (1 - Math.Sqrt(3.0) / 4.0));
            polylinesegment2.Points[0] = new Point(radius * 5.0 / 4.0, radius * (1 - Math.Sqrt(3.0) / 4.0));
            polylinesegment2.Points[1] = new Point(radius * 5.0 / 4.0, radius * (1 + Math.Sqrt(3.0) / 4.0));
            polylinesegment2.Points[2] = new Point(radius * 2.0, radius);

            ((Storyboard)Resources["storyboardRotate"]).RepeatBehavior = RepeatBehavior.Forever;
            ((Storyboard)Resources["storyboardRotate"]).Begin();
        }
    }
}
