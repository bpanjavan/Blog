﻿using System;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using System.Collections.Generic;

namespace IntrepidPrototype_Grid.Controls
{
    public class GameGrid : Canvas
    {
        private Canvas[,] arrSpace = null;
        private Border[,] arrGridBorder = null;
        private List<PieceMarker> colPieceMarker = null;
        private Canvas selectedSpace = null;

        private Storyboard _sbShiftPiece = null;

        public GameGrid()
        {
            colPieceMarker = new List<PieceMarker>();
            _sbShiftPiece = new Storyboard();
            _sbShiftPiece.Completed += new EventHandler(_sbShiftPiece_Completed);
            this.Resources.Add("SBShiftPiece", _sbShiftPiece);
        }

        void _sbShiftPiece_Completed(object sender, EventArgs e)
        {
            ((Storyboard)sender).Stop();
            DoubleAnimation daShiftPieceLeft = (DoubleAnimation)_sbShiftPiece.Children[0];
            double pieceLeft = (double)daShiftPieceLeft.To;
            string pieceName = (string)daShiftPieceLeft.GetValue(Storyboard.TargetNameProperty);
            Ellipse pieceEllipse = (Ellipse)this.FindName(pieceName);
            pieceEllipse.SetValue(Canvas.LeftProperty, pieceLeft);

            DoubleAnimation daShiftPieceTop = (DoubleAnimation)_sbShiftPiece.Children[1];
            double pieceTop = (double)daShiftPieceTop.To;
            pieceEllipse.SetValue(Canvas.TopProperty, pieceTop);
            this.ShiftPieceCompleted(this, new ShiftPieceCompletedEventArgs());
        }
        public event ShiftPieceCompletedEventHandler ShiftPieceCompleted;
        public delegate void ShiftPieceCompletedEventHandler (object sender, ShiftPieceCompletedEventArgs e);
        public class ShiftPieceCompletedEventArgs : EventArgs
        {
        }

        public void Load()
        {
            this.Children.Clear();

            arrSpace = new Canvas[NumSpacesX, NumSpacesY];
            arrGridBorder = new Border[NumSpacesX, NumSpacesY];
            //Construct my grid
            for (int i = 0; i < NumSpacesX; i++)
            {
                for (int j = 0; j < NumSpacesY; j++)
                {
                    Canvas space = new Canvas();
                    space.Height = SpaceHeight;
                    space.Width = SpaceWidth;
                    
                    Button spaceButton = new Button();
                    spaceButton.Style = this.GridButtonStyle;
                    spaceButton.Click += new RoutedEventHandler(spaceButton_Click);
                    spaceButton.Width = space.Width;
                    spaceButton.Height = SpaceHeight;
                    space.Children.Add(spaceButton);
                    
                    space.SetValue(Canvas.LeftProperty, (double)SpaceWidth * i);
                    space.SetValue(Canvas.TopProperty, (double)SpaceHeight * j);
                    space.SetValue(Canvas.ZIndexProperty, 100);
                    arrSpace[i, j] = space;
                    this.Children.Add(space);

                    Canvas canvasBorderFill = new Canvas();
                    canvasBorderFill.Height = SpaceHeight;
                    canvasBorderFill.Width = SpaceWidth;

                    Border border = new Border();
                    border.BorderThickness = new Thickness(LineThickness);
                    border.BorderBrush = new SolidColorBrush(LineColor);
                    border.SetValue(Canvas.LeftProperty, (double)SpaceWidth * i);
                    border.SetValue(Canvas.TopProperty, (double)SpaceHeight * j);
                    border.SetValue(Canvas.ZIndexProperty, 0);
                    border.Child = canvasBorderFill;
                    arrGridBorder[i, j] = border;
                    this.Children.Add(border);
                }
            }

        }

        void spaceButton_Click(object sender, RoutedEventArgs e)
        {
            Button spaceButton = (Button)sender;
            Canvas space = (Canvas)spaceButton.Parent;
            int locationX = 0;
            int locationY = 0;
            for (int i = 0; i < this.NumSpacesX; i++)
            {
                for (int j = 0; j < this.NumSpacesY; j++)
                {
                    if (this.arrSpace[i, j] == space)
                    {
                        locationX = i;
                        locationY = j;
                    }
                }
            }
            //MessageBox.Show(string.Format("Location: {0},{1}",locationX,locationY));
            SpaceClickedEventArgs args = new SpaceClickedEventArgs()
                                            {
                                                LocationX = locationX,
                                                LocationY = locationY
                                            };
            SpaceClicked(sender, args);
        }

        public event SpaceClickedEventHandler SpaceClicked;
        public delegate void SpaceClickedEventHandler(object sender, SpaceClickedEventArgs e);
        public class SpaceClickedEventArgs
        {
            public int LocationX { get; set; }
            public int LocationY { get; set; }
        }


        public void AddPiece(int locationX, int locationY, object piece)
        {
            // adding a child element to the grid space
            // for now, add an ellipse to the location specified
            //Button buttonPiece = new Button();
            //buttonPiece.Name = (Guid.NewGuid()).ToString();
            //buttonPiece.Style = this.PieceStyle;
            //buttonPiece.Width = 50;
            //buttonPiece.Height = 50;
            //buttonPiece.Click += new RoutedEventHandler(buttonPiece_Click);

            Ellipse ellipsePiece = new Ellipse();
            ellipsePiece.Name = (Guid.NewGuid()).ToString();
            ellipsePiece.Height = 50;
            ellipsePiece.Width = 50;
            ellipsePiece.Fill = new SolidColorBrush(System.Windows.Media.Colors.Green);
            ellipsePiece.StrokeThickness = 1;
            ellipsePiece.Stroke = new SolidColorBrush(System.Windows.Media.Colors.Green);

            //double pieceLeft = GetGridLocationLeft(locationX, buttonPiece.Width);
            //double pieceTop = GetGridLocationTop(locationY, buttonPiece.Height);
            //buttonPiece.SetValue(Canvas.LeftProperty, pieceLeft);
            //buttonPiece.SetValue(Canvas.TopProperty, pieceTop);
            //this.Children.Add(buttonPiece);

            double pieceLeft = GetGridLocationLeft(locationX, ellipsePiece.Width);
            double pieceTop = GetGridLocationTop(locationY, ellipsePiece.Height);
            ellipsePiece.SetValue(Canvas.LeftProperty, pieceLeft);
            ellipsePiece.SetValue(Canvas.TopProperty, pieceTop);
            ellipsePiece.SetValue(Canvas.ZIndexProperty, 50);
            this.Children.Add(ellipsePiece);

            // add it to our list of piece markers
            PieceMarker newMarker = new PieceMarker()
            {
                Piece = piece,
                PieceUIElement = ellipsePiece,
                LocationX = locationX,
                LocationY = locationY
            };
            this.colPieceMarker.Add(newMarker);
        }

        public void SelectSpace(int locationX, int locationY)
        {
            for (int i = 0; i < NumSpacesX; i++)
            {
                for (int j = 0; j < NumSpacesY; j++)
                {
                    //Canvas space = arrSpace[i, j];
                    Border border = arrGridBorder[i, j];//(Border)space.Parent;
                    border.BorderBrush = new SolidColorBrush(LineColor);
                }
            }

            this.selectedSpace = arrSpace[locationX, locationY];
            arrGridBorder[locationX, locationY].BorderBrush = new SolidColorBrush(System.Windows.Media.Colors.Cyan);
            //((Border)this.selectedSpace.Parent).BorderBrush = new SolidColorBrush(System.Windows.Media.Colors.Blue);
        }

        public void ClearSelectedSpace()
        {
            for (int i = 0; i < NumSpacesX; i++)
            {
                for (int j = 0; j < NumSpacesY; j++)
                {
                    //Canvas space = arrSpace[i, j];
                    Border border = arrGridBorder[i, j];//(Border)space.Parent;
                    border.BorderBrush = new SolidColorBrush(LineColor);
                }
            }
            this.selectedSpace = null;
        }

        public void MovePiece(int locationX1, int locationY1, int locationX2, int locationY2, object piece)
        {
            // Find the piece that matches and move it
            PieceMarker markerToMove = null;
            foreach (PieceMarker marker in this.colPieceMarker)
            {
                if (marker.Piece == piece)
                {
                    markerToMove = marker;
                    break;
                }
            }
            if (markerToMove == null)
            {
                MessageBox.Show("Error, no marker found with matching marker", "Error", MessageBoxButton.OK);
                return;
            }
            // move the UIElement to the respective next location
            markerToMove.LocationX = locationX2;
            markerToMove.LocationY = locationY2;

            UIElement element = markerToMove.PieceUIElement;
            double pieceLeft = GetGridLocationLeft(locationX2, ((Ellipse)element).Width);
            double pieceTop = GetGridLocationTop(locationY2, ((Ellipse)element).Height);

            _sbShiftPiece.Children.Clear();
            // Add animation for left shift
            DoubleAnimation daShiftPieceLeft = new DoubleAnimation();
            daShiftPieceLeft.SetValue(Storyboard.TargetNameProperty, ((Ellipse)element).Name);
            System.Windows.PropertyPath ppCanvasLeft = new PropertyPath("(Canvas.Left)");
            daShiftPieceLeft.SetValue(Storyboard.TargetPropertyProperty, ppCanvasLeft);
            daShiftPieceLeft.Duration = new Duration(new TimeSpan(0, 0, 0, 0, 500));
            daShiftPieceLeft.RepeatBehavior = new RepeatBehavior(1);
            daShiftPieceLeft.AutoReverse = false;
            daShiftPieceLeft.SetValue(Storyboard.TargetNameProperty, ((Ellipse)element).Name);
            daShiftPieceLeft.To = pieceLeft;
            _sbShiftPiece.Children.Add(daShiftPieceLeft);

            // Add animation for top shift
            DoubleAnimation daShiftPieceTop = new DoubleAnimation();
            daShiftPieceTop.SetValue(Storyboard.TargetNameProperty, ((Ellipse)element).Name);
            System.Windows.PropertyPath ppCanvasTop = new PropertyPath("(Canvas.Top)");
            daShiftPieceTop.SetValue(Storyboard.TargetPropertyProperty, ppCanvasTop);
            daShiftPieceTop.Duration = new Duration(new TimeSpan(0, 0, 0, 0, 500));
            daShiftPieceTop.SetValue(Storyboard.TargetNameProperty, ((Ellipse)element).Name);
            daShiftPieceTop.To = pieceTop;
            _sbShiftPiece.Children.Add(daShiftPieceTop);

            _sbShiftPiece.Begin();
            //element.SetValue(Canvas.LeftProperty, pieceLeft);
            //element.SetValue(Canvas.TopProperty, pieceTop);


        }

        private double GetGridLocationLeft(int locationX, double elementWidth)
        {
            double pieceLeft = SpaceWidth * locationX;
            // center it horizontally
            pieceLeft += (SpaceWidth / 2) - (elementWidth / 2);
            return pieceLeft;
        }

        private double GetGridLocationTop(int locationY, double elementHeight)
        {
            // make the bottom of the piece touch the bottom of the space.
            //   Them buffer it by 1/10 of the space height
            double pieceTop = SpaceHeight * locationY;
            pieceTop = (pieceTop + SpaceHeight) - elementHeight;
            pieceTop -= SpaceHeight / 10;
            return pieceTop;
        }

        public int NumSpacesX { get; set; }
        public int NumSpacesY { get; set; }
        public double LineThickness { get; set; }
        public Color LineColor { get; set; }
        public double SpaceWidth
        {
            get
            {
                if (NumSpacesX == 0)
                    return 0;
                return this.Width / NumSpacesX;
            }
        }

        public double SpaceHeight
        {
            get
            {
                if (NumSpacesY == 0)
                    return 0;
                return this.Height / NumSpacesY;
            }
        }

        public Style GridButtonStyle { get; set; }
//        public Style PieceStyleSelected { get; set; }

        private class PieceMarker
        {
            public object Piece { get; set; }
            public UIElement PieceUIElement { get; set; }
            public int LocationX { get; set; }
            public int LocationY { get; set; }
        }
    }
}
