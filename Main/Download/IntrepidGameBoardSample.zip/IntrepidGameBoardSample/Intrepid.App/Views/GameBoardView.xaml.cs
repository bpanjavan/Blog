﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using System.Windows.Navigation;
using IntrepidLib.Cover;
using Intrepid.App.Controllers;

namespace Intrepid.App.Views
{
    public partial class GameBoardView : Page, IGameBoardView
    {
        IGameBoard _gameBoardModel;
        IGameBoardController _gameBoardController;

        public GameBoardView(IGameBoardController gameBoardController, IGameBoard gameBoardModel):this()
        {
            _gameBoardController = gameBoardController;
            _gameBoardModel = gameBoardModel;

            _gameBoardModel.Loaded += new EventHandler(_gameBoardModel_Loaded);
            _gameBoardModel.PieceAdded += new PieceAddedEventHandler(_gameBoardModel_PieceAdded);
            _gameBoardModel.PieceMoved += new PieceMovedEventHandler(_gameBoardModel_PieceMoved);
            _gameBoardModel.SpaceSelected += new SpaceSelectedEventHandler(_gameBoardModel_SpaceSelected);
            _gameBoardModel.SelectedSpaceCleared += new SelectedSpaceClearedEventHandler(_gameBoardModel_SelectedSpaceCleared);

            this.gamegridMain.GridButtonStyle = (Style)this.Resources["GridButton"];
            //this.gamegridMain.PieceStyleSelected = (Style)this.Resources["PieceMarkerSelected"];
            this.gamegridMain.SpaceClicked += new IntrepidPrototype_Grid.Controls.GameGrid.SpaceClickedEventHandler(gamegridMain_SpaceClicked);
            PieceMoving = false;
            this.gamegridMain.ShiftPieceCompleted += new IntrepidPrototype_Grid.Controls.GameGrid.ShiftPieceCompletedEventHandler(gamegridMain_ShiftPieceCompleted);
        }

        void gamegridMain_ShiftPieceCompleted(object sender, IntrepidPrototype_Grid.Controls.GameGrid.ShiftPieceCompletedEventArgs e)
        {
            // let the controller know we're no longer in the middle of shifting a piece
            this.PieceMoving = false;
        }

        void _gameBoardModel_SelectedSpaceCleared(object sender, SelectedSpaceClearedEventArgs e)
        {
            this.gamegridMain.ClearSelectedSpace();
        }

        void gamegridMain_SpaceClicked(object sender, IntrepidPrototype_Grid.Controls.GameGrid.SpaceClickedEventArgs e)
        {
            //inform the controller
            _gameBoardController.SpaceClicked(e.LocationX, e.LocationY);
        }

        void _gameBoardModel_SpaceSelected(object sender, SpaceSelectedEventArgs e)
        {
            gamegridMain.SelectSpace(e.Space.LocationX, e.Space.LocationY);
        }

        void _gameBoardModel_PieceMoved(object sender, PieceMovedEventArgs e)
        {
            // let the controller know that we're in the middle of moving a piece
            PieceMoving = true;
            gamegridMain.MovePiece(e.LocationX1, e.LocationY1, e.LocationX2, e.LocationY2, e.Piece);
        }

        void _gameBoardModel_PieceAdded(object sender, PieceAddedEventArgs e)
        {
            // Add a piece and place it in the respective location
            gamegridMain.AddPiece(e.LocationX, e.LocationY, e.Piece);
        }

        void _gameBoardModel_Loaded(object sender, EventArgs e)
        {
            // when the board is loaded, we need to show our grid
            gamegridMain.NumSpacesX = _gameBoardModel.NumSpacesX;
            gamegridMain.NumSpacesY = _gameBoardModel.NumSpacesY;
            gamegridMain.Load();
        }

        /// <summary>
        /// With the implementation of the controller, this should not be called
        /// </summary>
        private GameBoardView()
        {
            InitializeComponent();
        }

        // Executes when the user navigates to this page.
        protected override void OnNavigatedTo(NavigationEventArgs e)
        {
        }

        public bool PieceMoving { get; private set; }

    }
}
