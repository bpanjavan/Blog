﻿using System;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;

using System.Collections.Generic;

namespace IntrepidLib.Cover
{
    public class GameBoardFactory
    {
        public class GameBoardSettings
        {
            public const string NumSpacesX = "NumSpacesX";
            public const string NumSpacesY = "NumSpacesY";
        }


        public IGameBoard CreateGameBoard(Dictionary<string, object> gameboardSettings)
        {
            int numSpacesX = 5;
            int numSpacesY = 5;

            // if gameboardSettings is not null, load the settings
            if (gameboardSettings != null)
            {
                if (gameboardSettings.ContainsKey(GameBoardSettings.NumSpacesX))
                    numSpacesX = (int)(gameboardSettings[GameBoardSettings.NumSpacesX]);
                if (gameboardSettings.ContainsKey(GameBoardSettings.NumSpacesY))
                    numSpacesY = (int)(gameboardSettings[GameBoardSettings.NumSpacesY]);
            }

            return new GameBoardBase(numSpacesX, numSpacesY);
        }

        public IPiece CreatePiece(string name)
        {
            return new PieceBase(name);
        }
    }
}
