﻿using System;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using System.Collections.Generic;

namespace IntrepidLib.Cover
{
    public interface IGameBoard
    {       
        void Load();
        ISpace GetSpace(int x, int y);
        void AddPiece(int x, int y, IPiece piece);
        void MovePiece(int x1, int y1, int x2, int y2);
        void MovePiece(IPiece piece, int x2, int y2);
        void SelectSpace(ISpace space);
        void ClearSelectedSpace();
        bool CanMoveToSpace(int x, int y);

        int NumSpacesX { get;}
        int NumSpacesY { get; }
        ISpace SelectedSpace { get; }

        event EventHandler Loaded;
        event PieceAddedEventHandler PieceAdded;
        event PieceMovedEventHandler PieceMoved;
        event SpaceSelectedEventHandler SpaceSelected;
        event SelectedSpaceClearedEventHandler SelectedSpaceCleared;
    }
}
