﻿using System;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;

namespace IntrepidLib.Cover
{
    public class SpaceBase : ISpace
    {
        internal SpaceBase() { }

        IPiece _piece;
        public IPiece Piece
        {
            get { return _piece; }
            internal set { _piece = value; }
        }

        int _locationX;
        public int LocationX
        {
            get { return _locationX; }
            internal set { _locationX = value; }
        }
        
        int _locationY;
        public int LocationY
        {
            get { return _locationY; }
            internal set { _locationY = value; }
        }

    }
}
