﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Controls;

namespace GarbageCollectionAnalysis.Surface
{
    public static class Extensions
    {
        public static void ReBind(this ListBox listBox, IEnumerable<ByteContainer> items)
        {
            listBox.ItemsSource = null;
            listBox.ItemsSource = items;
        }
    }
}
