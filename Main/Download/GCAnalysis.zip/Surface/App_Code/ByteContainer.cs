﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace GarbageCollectionAnalysis.Surface
{
    public class ByteContainer
    {
        private byte[] _data;

        public string Name { get; set; }

        /// <summary>
        /// Returns size in megabytes
        /// </summary>
        public int Size
        {
            get
            {
                if (_data == null)
                    return 500;
                return _data.Length / 1024 / 1024;
            }
        }

        public int DisplayLength
        {
            get
            {
                // 150 is the max length of the rectangle
                // 150 / 1000 = displaylength / size
                return (int)((150D / 1000D) * Size);
            }
        }

        // max megabytes is 1000
        public void SetSizeInMegabytes(int size)
        {
            int sizeInBytes = size * 1024 * 1024;
            _data = new byte[sizeInBytes];
        }
    }

}
