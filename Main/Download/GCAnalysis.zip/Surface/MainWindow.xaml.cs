﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Diagnostics;

namespace GarbageCollectionAnalysis.Surface
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        private List<ByteContainer> _colByteContainer;

        public MainWindow()
        {
            InitializeComponent();
        }

        private void buttonAddCollection_Click(object sender, RoutedEventArgs e)
        {
            string name = "NewContainer";
            if (textboxUpdateName.Text.Trim().Length != 0)
                name = textboxUpdateName.Text;
            int size = 500;
            if (textboxUpdateSize.Text.Trim().Length != 0)
            {
                if (int.TryParse(textboxUpdateSize.Text, out size) == false)
                {
                    MessageBox.Show("Could not parse size");
                    return;
                }
                if (size > 1000)
                {
                    MessageBox.Show("Max size is 1000");
                    return;
                }
            }

            ByteContainer newContainer = new ByteContainer() { Name = name };
            newContainer.SetSizeInMegabytes(size);

            _colByteContainer.Add(newContainer);
            listboxByteContainers.ReBind(_colByteContainer);
            UpdateStatusBytes();
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            _colByteContainer = new List<ByteContainer>();
            listboxByteContainers.ReBind(_colByteContainer);
        }

        private void buttonUpdate_Click(object sender, RoutedEventArgs e)
        {
            string name = "Capcom";
            if (textboxUpdateName.Text.Trim().Length != 0)
                name = textboxUpdateName.Text;
            int size = 500;
            if (textboxUpdateSize.Text.Trim().Length != 0)
            {
                if (int.TryParse(textboxUpdateSize.Text, out size) == false)
                {
                    MessageBox.Show("Could not parse size");
                    return;
                }
                if (size > 1000)
                {
                    MessageBox.Show("Max size is 1000");
                    return;
                }
            }

            if (listboxByteContainers.SelectedIndex == -1)
                return;

            var byteContainer = _colByteContainer[listboxByteContainers.SelectedIndex];
            byteContainer.Name = name;
            byteContainer.SetSizeInMegabytes(size);
            listboxByteContainers.ReBind(_colByteContainer);
            UpdateStatusBytes();
        }

        private void buttonDelete_Click(object sender, RoutedEventArgs e)
        {
            if (listboxByteContainers.SelectedIndex == -1)
                return;

            var byteContainer = _colByteContainer[listboxByteContainers.SelectedIndex];
            _colByteContainer.Remove(byteContainer);
            listboxByteContainers.ReBind(_colByteContainer);

            UpdateStatusBytes();
        }

        private void UpdateStatusBytes()
        {
            textblockStatus.Text = "Total Memory (MB): " + GetTotalProcessMemoryInMB().ToString("N2");
        }

        private double GetTotalProcessMemoryInMB()
        {
            return Process.GetCurrentProcess().PrivateMemorySize64 / 1024D / 1024D;
        }

        private void buttonGarbageCollect_Click(object sender, RoutedEventArgs e)
        {
            GC.Collect();
            UpdateStatusBytes();
        }

    }
}
