﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using System.IO;
using System.Diagnostics;
using System.Threading;

namespace GarbageCollectionAnalysis
{
    class Program
    {
        static void Main(string[] args)
        {
            bool setCollectionToNull = false;   // whether to set the first collection to NULL or not
            int numberPlayers = 30;             // Vary based on how much memory you have available

            Console.WriteLine("Ready");
            Console.Read();


            // find out my total process memory size
            Console.WriteLine("Before we get started");
            Console.WriteLine("Memory in process (MB): " + GetTotalProcessMemoryInMB().ToString("N2"));
            Console.WriteLine("Total Memory: {0}", GetTotalMemoryAllocatedInMB().ToString("N2"));

            List<Player> colPlayer = new List<Player>();

            for (int i = 0; i < numberPlayers; i++)
            {
                GeneratePlayers(colPlayer);
            }

            Console.WriteLine("After phase I");
            Console.WriteLine("Memory in process (MB): " + GetTotalProcessMemoryInMB().ToString("N2"));
            Console.WriteLine("Total Memory: {0}", GetTotalMemoryAllocatedInMB().ToString("N2"));

            Thread.Sleep(5000);

            if (setCollectionToNull)
            {
                colPlayer = null;
            }


            List<Player> colPlayer2 = new List<Player>();
            for (int i = 0; i < numberPlayers; i++)
            {
                GeneratePlayers(colPlayer2);
            }
            Console.WriteLine("After phase II");
            Console.WriteLine("Memory in process (MB): " + GetTotalProcessMemoryInMB().ToString("N2"));
            Console.WriteLine("Total Memory: {0}", GetTotalMemoryAllocatedInMB().ToString("N2"));

            Console.WriteLine("Done");
            Console.Read();
            Console.Read();
        }

        public static double GetTotalProcessMemoryInMB()
        {
            return Process.GetCurrentProcess().PrivateMemorySize64 / 1024D / 1024D;
        }

        public static double GetTotalMemoryAllocatedInMB()
        {
            return GC.GetTotalMemory(false) / 1024D / 1024D;
        }

        private static void GeneratePlayers(List<Player> colPlayer)
        {
            for (int i = 0; i < 1000000; i++)
            {
                Player p1 = new Player() { Name = "Bryan", Age = 26 };
                colPlayer.Add(p1);
            }
        }
    }
}




