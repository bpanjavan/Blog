﻿using System;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;

namespace SL4LinqToXML.InventoryProxy {

    // using this I can extend the web service class
    public partial class ProductInfo
	{
        public void TestMethod()
        {
            
        }
	}
}
