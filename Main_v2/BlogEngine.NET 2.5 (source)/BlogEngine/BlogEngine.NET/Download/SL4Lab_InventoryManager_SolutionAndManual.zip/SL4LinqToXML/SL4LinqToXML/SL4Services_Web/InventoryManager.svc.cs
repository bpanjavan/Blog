﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;
using System.Configuration;

namespace SL4Services_Web
{
    // NOTE: You can use the "Rename" command on the "Refactor" menu to change the class name "InventoryManager" in code, svc and config file together.
    //Frag#4: Provide empty IInventoryManager implementation inside // InventoryManager.svc.cs 
    public class InventoryManager : IInventoryManager
    {
        #region IInventoryManager Members

        //Frag#7: Implement GetInventoryBySku using LINQ in InventoryManager.svc.cs 
        public List<ProductInfo> GetInventoryBySku(string sku) 
        { 
            string constr = ConfigurationManager.ConnectionStrings["AdventureWorksConnectionString"] .ConnectionString; 
            AdventureWorksDataContext advDC = new AdventureWorksDataContext(constr); 
            IEnumerable<ProductInfo> products = from p in advDC.Products 
                                                where p.ProductNumber.StartsWith(sku) 
                                                select new ProductInfo 
                                                    { 
                                                        ProductID = p.ProductID, 
                                                        ProductName = p.Name, 
                                                        ProductNumber = p.ProductNumber, 
                                                        ProductReorderPoint = p.ReorderPoint, 
                                                        ProductSafetyStockLevel = p.SafetyStockLevel 
                                                    }; 
            return new List<ProductInfo>(products); 
        }

        //Frag#8: Implement GetInventoryByName using LINQ in InventoryManager.svc.cs 
        public List<ProductInfo> GetInventoryByName(string name) 
        { 
            string constr = ConfigurationManager.ConnectionStrings["AdventureWorksConnectionString"].ConnectionString; 
            AdventureWorksDataContext advDC = new AdventureWorksDataContext(constr); 
            IEnumerable<ProductInfo> products = from p in advDC.Products 
                                                where p.Name.ToLower().Contains(name.ToLower()) 
                                                select new ProductInfo 
                                                { 
                                                    ProductID = p.ProductID, 
                                                    ProductName = p.Name, 
                                                    ProductNumber = p.ProductNumber, 
                                                    ProductReorderPoint = p.ReorderPoint, 
                                                    ProductSafetyStockLevel = p.SafetyStockLevel 
                                                }; 
            List<ProductInfo> pList = new List<ProductInfo>(products); 
            return pList; 
        }
        
        #endregion
    }
    
    //Frag#2: Create ProductInfo [DataContract] inside InventoryManager.svc.cs 
    [DataContract] 
    public class ProductInfo 
    { 
        [DataMember] 
        public int ProductID; 
        
        [DataMember] 
        public string ProductName; 
        
        [DataMember] 
        public string ProductNumber; 
        
        [DataMember] 
        public int ProductSafetyStockLevel;
    
        [DataMember] 
        public int ProductReorderPoint; 
    }
}




