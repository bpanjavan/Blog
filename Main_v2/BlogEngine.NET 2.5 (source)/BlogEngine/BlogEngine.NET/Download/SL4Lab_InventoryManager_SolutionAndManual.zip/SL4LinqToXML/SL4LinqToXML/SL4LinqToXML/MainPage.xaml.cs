﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using SL4LinqToXML.App_Code;

namespace SL4LinqToXML
{
    public partial class MainPage : UserControl
    {
        public MainPage()
        {
            InitializeComponent();
        }

        private void radiobuttonSearchBySku_Click(object sender, RoutedEventArgs e)
        {
            if (this.textSku.Text.Length > 0) 
                this.borderInventoryView.Visibility = Visibility.Visible;
        }

        private void radiobuttonSearchByName_Click(object sender, RoutedEventArgs e)
        {
            this.borderInventoryView.Visibility = Visibility.Collapsed;
        }

        private void hyperlinkbuttonSearchNow_Click(object sender, RoutedEventArgs e) 
        { 

            
            // Get my data provider.  To my page, it doesn't matter what the back-end data store is
            IInventoryManager im = InventoryManagerFactory.GetInventoryManager();

            if (this.radiobuttonSearchBySku.IsChecked == true)
            {
                im.GetInventoryBySkuCompleted += new GetInventoryCompletedEventHandler(GetInventoryBySKUCompleted);
                im.GetInventoryBySku(textSku.Text);
            }
             else
            {
                im.GetInventoryByNameCompleted += 
                    new GetInventoryCompletedEventHandler(GetInventoryByNameCompleted);
                im.GetInventoryByName(textSku.Text);
            }
        }

        private void GetInventoryByNameCompleted(IEnumerable<ProductInfo> colProductInfo, string error)
        {
            ResetDisplay();
            if (error == null)
            {
                productlistviewMain.dataGridProductListBase.DataContext = colProductInfo;
            }

        }


        private void GetInventoryBySKUCompleted(IEnumerable<ProductInfo> colProductInfo, string error)
        {
            ResetDisplay();
            if (error == null && colProductInfo.Count<ProductInfo>() > 0)
            {
                gridInventoryDetails.DataContext = colProductInfo.First<ProductInfo>(); 
            } 
            
        }
        //Frag#5 Add ResetDisplay to Page.xaml.cs 
        private void ResetDisplay() 
        {   
            if (this.textSku.Text.Length > 0) 
            { 
                if (this.radiobuttonSearchBySku.IsChecked == true) 
                { 
                    this.borderInventoryView.Visibility = Visibility.Visible; 
                    this.borderInventoryTableView.Visibility = Visibility.Collapsed; 
                } 
                else 
                { 
                    this.borderInventoryView.Visibility = Visibility.Collapsed; 
                    this.borderInventoryTableView.Visibility = Visibility.Visible; 
                } 
            } 
            else 
            { 
                this.borderInventoryView.Visibility = Visibility.Collapsed; 
                this.borderInventoryTableView.Visibility = Visibility.Collapsed; 
            } 
        }

    }
}
