﻿using System;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;

namespace SL4LinqToXML.App_Code
{
    public class ProductInfo 
    { 
        public int ProductID { get; set; }
        public string ProductName { get; set; }
        public string ProductNumber { get; set; }
        public int ProductSafetyStockLevel { get; set; }
        public int ProductReorderPoint { get; set; }
    } 
}
