﻿using System;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using System.Collections.Generic;
using System.Linq;

namespace SL4LinqToXML.App_Code
{
    public class InventoryManagerMock : IInventoryManager
    {

        public void GetInventoryBySku(string searchSKU)
        {
            List<ProductInfo> productData = GetSampleData();
            var products = from product in productData
                           where product.ProductNumber.ToLower().Contains(searchSKU.ToLower())
                           select product;
            this.GetInventoryBySkuCompleted(products, null);
        }

        private List<ProductInfo> GetSampleData()
        {
            List<ProductInfo> products = new List<ProductInfo>();
            products.Add(
                new ProductInfo
                {
                    ProductID = 1,
                    ProductName = "Adjustable Race",
                    ProductNumber = "AR-5381",
                    ProductSafetyStockLevel = 1000,
                    ProductReorderPoint = 750
                }
                        );

            #region Add more products
            #endregion

            products.Add(
                new ProductInfo
                {
                    ProductID = 2,
                    ProductName = "Bearing Ball",
                    ProductNumber = "BA-8327",
                    ProductSafetyStockLevel = 1000,
                    ProductReorderPoint = 750
                }
                );
            products.Add(new ProductInfo
            {
                ProductID = 3,
                ProductName = "BB Ball Bearing",
                ProductNumber = "BE-2349",
                ProductSafetyStockLevel = 800,
                ProductReorderPoint = 600
            }
            );
            products.Add(new ProductInfo
            {
                ProductID = 4,
                ProductName = "Headset Ball Bearings",
                ProductNumber = "BE-2908",
                ProductSafetyStockLevel = 800,
                ProductReorderPoint = 600
            });

            products.Add(new ProductInfo
            {
                ProductID = 327,
                ProductName = "Down Tube",
                ProductNumber = "DT-2377",
                ProductSafetyStockLevel = 800,
                ProductReorderPoint = 600
            }
                );

            products.Add(
                new ProductInfo
                {
                    ProductID = 328,
                    ProductName = "Mountain End Caps",
                    ProductNumber = "EC-M092",
                    ProductSafetyStockLevel = 1000,
                    ProductReorderPoint = 750
                }
                );

            products.Add(new ProductInfo
            {
                ProductID = 371,
                ProductName = "Thin-Jam Hex Nut 7",
                ProductNumber = "HJ-7161",
                ProductSafetyStockLevel = 1000,
                ProductReorderPoint = 750
            }
            );
            products.Add(new ProductInfo
            {
                ProductID = 372,
                ProductName = "Thin-Jam Hex Nut 8",
                ProductNumber = "HJ-7162",
                ProductSafetyStockLevel = 1000,
                ProductReorderPoint = 750
            }
                );
            products.Add(new ProductInfo
            {
                ProductID = 373,
                ProductName = "Thin-Jam Hex Nut 12",
                ProductNumber = "HJ-9080",
                ProductSafetyStockLevel = 1000,
                ProductReorderPoint = 750
            });

            products.Add(new ProductInfo
            {
                ProductID = 374,
                ProductName = "Thin-Jam Hex Nut 11",
                ProductNumber = "HJ-9161",
                ProductSafetyStockLevel = 1000,
                ProductReorderPoint = 750
            });

            return products;
        }

        public event GetInventoryCompletedEventHandler GetInventoryBySkuCompleted;

        public void GetInventoryByName(string searchName)
        {
            List<ProductInfo> productData = GetSampleData();
            var products = from product in productData
                           where product.ProductName.ToLower().Contains(searchName.ToLower())
                           select product;
            this.GetInventoryByNameCompleted(products, null);
        }

        public event GetInventoryCompletedEventHandler GetInventoryByNameCompleted;


    }
}
