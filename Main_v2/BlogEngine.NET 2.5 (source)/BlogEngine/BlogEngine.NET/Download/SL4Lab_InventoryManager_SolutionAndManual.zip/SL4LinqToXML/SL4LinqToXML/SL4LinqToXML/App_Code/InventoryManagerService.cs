﻿using System;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using System.Collections.Generic;
using System.Linq;
using System.Xml.Linq;
using SL4LinqToXML.SLUtil;

namespace SL4LinqToXML.App_Code
{
    public class InventoryManagerService : IInventoryManager
    {

        public void GetInventoryBySku(string searchSKU)
        {
            InventoryProxy.InventoryManagerClient inv = new InventoryProxy.InventoryManagerClient();
            inv.GetInventoryBySkuCompleted += new EventHandler<InventoryProxy.GetInventoryBySkuCompletedEventArgs>(inv_GetInventoryBySkuCompleted);
            inv.GetInventoryBySkuAsync(searchSKU);
        }

        void inv_GetInventoryBySkuCompleted(object sender, InventoryProxy.GetInventoryBySkuCompletedEventArgs e)
        {
            string exceptionMessage = null;
            if (e.Error != null)
                exceptionMessage = e.Error.Message;

            List<ProductInfo> colToReturn = ProductInfoList_Populate(e.Result);
            this.GetInventoryBySkuCompleted(colToReturn, exceptionMessage);
        }

        public event GetInventoryCompletedEventHandler GetInventoryBySkuCompleted;

        public void GetInventoryByName(string searchName)
        {
            InventoryProxy.InventoryManagerClient inv = new InventoryProxy.InventoryManagerClient();
            inv.GetInventoryByNameCompleted += 
                new EventHandler<InventoryProxy.GetInventoryByNameCompletedEventArgs>(inv_GetInventoryByNameCompleted);
            inv.GetInventoryByNameAsync(searchName);
        }

        void inv_GetInventoryByNameCompleted(object sender, InventoryProxy.GetInventoryByNameCompletedEventArgs e)
        {
            string exceptionMessage = null;
            if (e.Error != null)
                exceptionMessage = e.Error.Message;

            List<ProductInfo> colToReturn = ProductInfoList_Populate(e.Result);
            this.GetInventoryByNameCompleted(colToReturn, exceptionMessage);
        }

        public event GetInventoryCompletedEventHandler GetInventoryByNameCompleted;

        private List<ProductInfo> ProductInfoList_Populate(ICollection<InventoryProxy.ProductInfo> result)
        {
            List<ProductInfo> colToReturn = new List<ProductInfo>();
            foreach (InventoryProxy.ProductInfo pi in result)
            {
                ProductInfo p = new ProductInfo
                {
                    ProductID = pi.ProductID,
                    ProductName = pi.ProductName,
                    ProductNumber = pi.ProductNumber,
                    ProductSafetyStockLevel = pi.ProductSafetyStockLevel,
                    ProductReorderPoint = pi.ProductReorderPoint
                };
                colToReturn.Add(p);
            }

            return colToReturn;
        }

    }
}
