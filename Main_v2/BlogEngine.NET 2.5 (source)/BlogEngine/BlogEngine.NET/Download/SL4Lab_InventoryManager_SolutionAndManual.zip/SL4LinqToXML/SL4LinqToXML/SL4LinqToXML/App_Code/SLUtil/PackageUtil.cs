﻿using System;
using System.Collections.Generic;
using System.Windows;
using System.Windows.Markup;
using System.Windows.Resources;
using System.Reflection;
using System.Net;
using System.IO;
using System.Xml;
using System.Xml.Linq;

namespace SL4LinqToXML.SLUtil
{
    internal class PackageUtil
    {
        internal static XElement GetXmlDocFromDefaultPackage(string fileName)
        {
            XmlReaderSettings settings = new XmlReaderSettings();
            settings.XmlResolver = new XmlXapResolver();
            XmlReader reader = XmlReader.Create("Data/Products.xml");
            
            //Create XElement from XML
            XElement element = XElement.Load(reader);
            return element;
        }
    }
}