namespace SL4Services_Web
{
    partial class AdventureWorksDataContext
    {
    }
}
