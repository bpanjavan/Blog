﻿using System;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using System.Collections.Generic;
using System.Linq;
using System.Xml.Linq;
using SL4LinqToXML.SLUtil;

namespace SL4LinqToXML.App_Code
{
    public class InventoryManagerXML : IInventoryManager
    {

        public void GetInventoryBySku(string searchSKU)
        {
            XElement e = PackageUtil.GetXmlDocFromDefaultPackage("Products.xml");
            var products = from product in e.Elements("product")
                           where ((string)product.Attribute("ProductNumber")).Contains(searchSKU)
                           select product;

            List<ProductInfo> colToReturn = ProductInfoList_Populate(products);
            this.GetInventoryBySkuCompleted(colToReturn, null);
        }

        public event GetInventoryCompletedEventHandler GetInventoryBySkuCompleted;

        public void GetInventoryByName(string searchName)
        {
            XElement e = PackageUtil.GetXmlDocFromDefaultPackage("Products.xml");
            var products = from product in e.Elements("product")
                           where ((string)product.Attribute("ProductName")).ToLower().Contains(searchName.ToLower())
                           select product;

            List<ProductInfo> colToReturn = ProductInfoList_Populate(products);
            this.GetInventoryByNameCompleted(colToReturn, null);
        }

        public event GetInventoryCompletedEventHandler GetInventoryByNameCompleted;

        private List<ProductInfo> ProductInfoList_Populate(IEnumerable<XElement> products)
        {
            List<ProductInfo> colToReturn = new List<ProductInfo>();
            foreach (XElement el in products)
            {
                ProductInfo p = new ProductInfo
                {
                    ProductID = (int)el.Attribute("ProductID"),
                    ProductName = (string)el.Attribute("ProductName"),
                    ProductNumber = (string)el.Attribute("ProductNumber"),
                    ProductSafetyStockLevel = (int)el.Attribute("ProductSafetyStockLevel"),
                    ProductReorderPoint = (int)el.Attribute("ProductReorderPoint")
                };
                colToReturn.Add(p);
            }

            return colToReturn;
        }

    }
}


