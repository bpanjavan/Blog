﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;

namespace SL4Services_Web
{
    // NOTE: You can use the "Rename" command on the "Refactor" menu to change the interface name "IInventoryManager" in both code and config file together.
    [ServiceContract]
    public interface IInventoryManager
    {

        [OperationContract]
        List<ProductInfo> GetInventoryBySku(string sku);

        [OperationContract]
        List<ProductInfo> GetInventoryByName(string name);
    }
}

